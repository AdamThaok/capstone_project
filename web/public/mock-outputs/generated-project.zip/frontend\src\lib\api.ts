const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

export type Order = {
  id: string;
  customerId: string;
  status: "Pending" | "Paid" | "Shipped" | "Cancelled";
  total: number;
  itemIds: string[];
};

export async function listOrders(): Promise<Order[]> {
  return (await fetch(`${BASE}/orders`)).json();
}

export async function getOrder(id: string): Promise<Order> {
  return (await fetch(`${BASE}/orders/${id}`)).json();
}

export async function createOrder(o: Order): Promise<Order> {
  return (await fetch(`${BASE}/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(o),
  })).json();
}

export async function payOrder(id: string): Promise<Order> {
  return (await fetch(`${BASE}/orders/${id}/pay`, { method: "POST" })).json();
}

export async function shipOrder(id: string): Promise<Order> {
  return (await fetch(`${BASE}/orders/${id}/ship`, { method: "POST" })).json();
}

export async function cancelOrder(id: string): Promise<Order> {
  return (await fetch(`${BASE}/orders/${id}`, { method: "DELETE" })).json();
}
