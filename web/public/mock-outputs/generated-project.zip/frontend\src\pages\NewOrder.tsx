import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { createOrder } from "../lib/api";

export default function NewOrder() {
  const nav = useNavigate();
  const [customerId, setCustomerId] = useState("");
  const [total,      setTotal]      = useState(0);
  const [itemIds,    setItemIds]    = useState("item-1");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const id = crypto.randomUUID();
    await createOrder({
      id,
      customerId,
      status:  "Pending",
      total,
      itemIds: itemIds.split(",").map((s) => s.trim()).filter(Boolean),
    });
    nav(`/orders/${id}`);
  }

  return (
    <main style={{ padding: 20 }}>
      <h1>New Order</h1>
      <form onSubmit={submit} style={{ display: "grid", gap: 12, maxWidth: 360 }}>
        <label>Customer ID <input value={customerId} onChange={(e) => setCustomerId(e.target.value)} required /></label>
        <label>Total       <input type="number" step="0.01" value={total} onChange={(e) => setTotal(+e.target.value)} required /></label>
        <label>Item IDs    <input value={itemIds} onChange={(e) => setItemIds(e.target.value)} placeholder="item-1,item-2" required /></label>
        <button type="submit">Create</button>
      </form>
    </main>
  );
}
