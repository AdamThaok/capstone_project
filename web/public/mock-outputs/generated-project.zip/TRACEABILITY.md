# Traceability: OPM → Code

Every element in the source OPM diagram maps to a specific code artifact.

## Objects

| OPM ID | Name     | Artifact                                |
|--------|----------|-----------------------------------------|
| O1     | Customer | backend/app/models/customer.py          |
| O2     | Order    | backend/app/models/order.py             |
| O3     | Item     | backend/app/models/item.py              |
| O4     | Payment  | backend/app/services/transitions.py:42  |

## Processes

| OPM ID | Name            | Artifact                                       |
|--------|-----------------|------------------------------------------------|
| P1     | Place Order     | backend/app/routes/orders.py POST /orders      |
| P2     | Cancel Order    | backend/app/routes/orders.py DELETE /orders/:id |
| P3     | Process Payment | backend/app/routes/orders.py POST /orders/:id/pay |
| P4     | Ship Order      | backend/app/routes/orders.py POST /orders/:id/ship |

## Links

| OPM ID | Type          | Artifact                                  |
|--------|---------------|-------------------------------------------|
| L1     | agent         | firebase/firestore.rules line 14          |
| L3     | aggregation   | backend/app/models/order.py items field   |
| L5     | state-change  | backend/app/services/transitions.py pay() |
| L6     | state-change  | backend/app/services/transitions.py ship() |
| L8     | state-change  | backend/app/services/transitions.py cancel() |

## Business Rules

| ID   | Rule                                                        | Location                            |
|------|-------------------------------------------------------------|-------------------------------------|
| BR1  | Pending→Paid only after Payment consumption                 | transitions.py pay() precondition   |
| BR2  | Paid→Shipped via Ship Order                                 | transitions.py ship() precondition  |
| BR3  | Pending→Cancelled via Cancel Order                          | transitions.py cancel() precondition |
| BR4  | Order must aggregate at least one Item                      | models/order.py validator            |
