"""OPM object O1: Customer.

Agent for P1 (Place Order) and P2 (Cancel Order).
"""

from pydantic import BaseModel, EmailStr

class Customer(BaseModel):
    id: str
    name: str
    email: EmailStr
