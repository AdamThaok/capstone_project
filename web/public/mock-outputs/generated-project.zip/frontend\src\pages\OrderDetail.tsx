import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getOrder, payOrder, shipOrder, cancelOrder, Order } from "../lib/api";

export default function OrderDetail() {
  const { id } = useParams();
  const [o, setO] = useState<Order | null>(null);

  async function reload() {
    if (id) setO(await getOrder(id));
  }

  useEffect(() => { reload(); }, [id]);

  if (!o) return <main style={{ padding: 20 }}>Loading...</main>;

  return (
    <main style={{ padding: 20 }}>
      <h1>Order {o.id}</h1>
      <p>Status: <strong>{o.status}</strong></p>
      <p>Total: ${o.total.toFixed(2)}</p>
      <div style={{ display: "flex", gap: 8 }}>
        <button onClick={() => payOrder(o.id).then(setO)}    disabled={o.status !== "Pending"}>Pay</button>
        <button onClick={() => shipOrder(o.id).then(setO)}   disabled={o.status !== "Paid"}>Ship</button>
        <button onClick={() => cancelOrder(o.id).then(setO)} disabled={o.status !== "Pending"}>Cancel</button>
      </div>
    </main>
  );
}
