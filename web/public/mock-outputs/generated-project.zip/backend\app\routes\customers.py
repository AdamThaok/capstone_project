"""Customer routes — OPM object O1."""

from fastapi import APIRouter
from app.models.customer import Customer
from app.services.firestore import client

router = APIRouter()

@router.post("")
def create_customer(c: Customer):
    client().collection("customers").document(c.id).set(c.model_dump())
    return c

@router.get("/{customer_id}")
def get_customer(customer_id: str):
    doc = client().collection("customers").document(customer_id).get()
    return doc.to_dict() | {"id": doc.id} if doc.exists else None
