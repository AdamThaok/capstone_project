# OPM-Generated Project

Auto-generated from an Object-Process Methodology (OPM) diagram.

## Architecture

- **Backend**: FastAPI (Python) — REST API
- **Database**: Firebase Firestore — collections for Customer, Order, Item
- **Frontend**: React + TypeScript — 3 screens (OrderList, OrderDetail, NewOrder)
- **Infra**: Docker Compose with Firestore emulator

## Run

```bash
cp .env.example .env
docker compose up
```

Frontend: http://localhost:5173
Backend: http://localhost:8000
Firestore emulator UI: http://localhost:4000

## Traceability

See `TRACEABILITY.md` for OPM → code mapping.
