"""State transition logic — enforces OPM state links L5, L6, L8.

Each transition validates source state before applying, per ISO 19450
§7.3.1: intermediate states prohibited, transitions atomic.
"""

from fastapi import HTTPException
from app.models.order import OrderStatus
from app.services.firestore import client

def _get_order(order_id: str):
    doc = client().collection("orders").document(order_id).get()
    if not doc.exists:
        raise HTTPException(404, f"Order {order_id} not found")
    return doc.to_dict() | {"id": doc.id}

def pay(order_id: str):
    """L5: Pending → Paid via P3 Process Payment. BR1."""
    o = _get_order(order_id)
    if o["status"] != OrderStatus.Pending:
        raise HTTPException(409, f"Cannot pay order in {o['status']} state")
    client().collection("orders").document(order_id).update({"status": OrderStatus.Paid.value})
    return _get_order(order_id)

def ship(order_id: str):
    """L6: Paid → Shipped via P4 Ship Order. BR2."""
    o = _get_order(order_id)
    if o["status"] != OrderStatus.Paid:
        raise HTTPException(409, f"Cannot ship order in {o['status']} state")
    client().collection("orders").document(order_id).update({"status": OrderStatus.Shipped.value})
    return _get_order(order_id)

def cancel(order_id: str):
    """L8: Pending → Cancelled via P2 Cancel Order. BR3."""
    o = _get_order(order_id)
    if o["status"] != OrderStatus.Pending:
        raise HTTPException(409, f"Cannot cancel order in {o['status']} state")
    client().collection("orders").document(order_id).update({"status": OrderStatus.Cancelled.value})
    return _get_order(order_id)
