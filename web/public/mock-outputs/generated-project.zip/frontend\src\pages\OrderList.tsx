import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { listOrders, Order } from "../lib/api";

export default function OrderList() {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    listOrders().then(setOrders).catch(console.error);
  }, []);

  return (
    <main style={{ padding: 20 }}>
      <h1>Orders</h1>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>
            <th align="left">ID</th>
            <th align="left">Status</th>
            <th align="right">Total</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((o) => (
            <tr key={o.id}>
              <td><Link to={`/orders/${o.id}`}>{o.id}</Link></td>
              <td>{o.status}</td>
              <td align="right">${o.total.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
