import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import OrderList   from "./pages/OrderList";
import OrderDetail from "./pages/OrderDetail";
import NewOrder    from "./pages/NewOrder";

export default function App() {
  return (
    <BrowserRouter>
      <nav style={{ padding: 12, borderBottom: "1px solid #eee" }}>
        <Link to="/">Orders</Link> · <Link to="/orders/new">New Order</Link>
      </nav>
      <Routes>
        <Route path="/"             element={<OrderList   />} />
        <Route path="/orders/:id"   element={<OrderDetail />} />
        <Route path="/orders/new"   element={<NewOrder    />} />
      </Routes>
    </BrowserRouter>
  );
}
