"""OPM object O3: Item.

Aggregated by Order (L3).
"""

from pydantic import BaseModel

class Item(BaseModel):
    id:      str
    orderId: str
    sku:     str
    qty:     int
    price:   float
