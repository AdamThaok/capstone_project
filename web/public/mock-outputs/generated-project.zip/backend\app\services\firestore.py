"""Firestore client wrapper.

Uses google-cloud-firestore with emulator when FIRESTORE_EMULATOR_HOST is set.
"""

import os
from google.cloud import firestore

def client() -> firestore.Client:
    project = os.environ.get("GOOGLE_CLOUD_PROJECT", "opm-demo")
    return firestore.Client(project=project)
