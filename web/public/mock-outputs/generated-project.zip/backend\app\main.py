"""FastAPI entry point.

Derived from OPM SD diagram. Routes registered per process:
  P1 Place Order     → POST   /orders
  P2 Cancel Order    → DELETE /orders/:id
  P3 Process Payment → POST   /orders/:id/pay
  P4 Ship Order      → POST   /orders/:id/ship
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import orders, customers

app = FastAPI(title="OPM-Generated API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(orders.router, prefix="/orders", tags=["orders"])
app.include_router(customers.router, prefix="/customers", tags=["customers"])

@app.get("/health")
def health():
    return {"status": "ok"}
