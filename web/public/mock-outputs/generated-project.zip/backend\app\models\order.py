"""OPM object O2: Order.

States (from OPM): Pending | Paid | Shipped | Cancelled.
L3 aggregation → items list.
"""

from enum import Enum
from typing import List
from pydantic import BaseModel, Field

class OrderStatus(str, Enum):
    Pending   = "Pending"
    Paid      = "Paid"
    Shipped   = "Shipped"
    Cancelled = "Cancelled"

class Order(BaseModel):
    id:         str
    customerId: str
    status:     OrderStatus = OrderStatus.Pending
    total:      float
    # BR4: aggregation from OPM requires at least one item.
    itemIds:    List[str]   = Field(default_factory=list, min_length=1)
