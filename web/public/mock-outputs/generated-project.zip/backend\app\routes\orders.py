"""Order routes — maps OPM processes P1..P4 to HTTP endpoints."""

from fastapi import APIRouter
from app.models.order import Order
from app.services import transitions
from app.services.firestore import client

router = APIRouter()

@router.post("")
def create_order(order: Order):
    """P1: Place Order."""
    client().collection("orders").document(order.id).set(order.model_dump())
    return order

@router.get("")
def list_orders():
    return [d.to_dict() | {"id": d.id} for d in client().collection("orders").stream()]

@router.get("/{order_id}")
def get_order(order_id: str):
    doc = client().collection("orders").document(order_id).get()
    return doc.to_dict() | {"id": doc.id} if doc.exists else None

@router.delete("/{order_id}")
def cancel_order(order_id: str):
    """P2: Cancel Order (L8 transition)."""
    return transitions.cancel(order_id)

@router.post("/{order_id}/pay")
def pay_order(order_id: str):
    """P3: Process Payment (L5 transition)."""
    return transitions.pay(order_id)

@router.post("/{order_id}/ship")
def ship_order(order_id: str):
    """P4: Ship Order (L6 transition)."""
    return transitions.ship(order_id)
